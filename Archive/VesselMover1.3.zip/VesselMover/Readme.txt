Installation:
The folder containing these files ("VesselMover") should be in KSP's GameData folder.

Usage:
Press Alt-P to pick up and place vessel. It must be landed or splashed down in order to pick it up.

Controls:
Movement - pitch/yaw keys (WASD by default).
Roll to roll (QE by default), 
Translation to pitch and yaw (IJKL by default) 
Translate FWD (H by default) to auto-level planes
Translate BACK (N by default) to auto-upright rockets