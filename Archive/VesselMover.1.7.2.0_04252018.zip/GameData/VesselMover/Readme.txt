Installation:
The folder containing these files ("VesselMover") should be in KSP's GameData folder.

Usage:
Open the vessel mover menu by clicking the icon on the toolbar.  Your vessel must be landed to use the move or spawn features.

Click move vessel to begin moving
Click place vessel to set the vessel down where you want it.
Click Drop vessel to relase the vessel at what ever altitude you ahve set.  Vessel begins free fall from that point.

Click spawn vessel to open the craft browser.  Select a craft, then select a place to spawn it.  It will spawn in vessel-move mode so you can reposition it or rotate it before placing it down.

Controls: (Also displayed in the help window when a vessel is in move mode)
Movement - pitch/yaw keys (WASD by default).
Roll to roll (QE by default), 
Translation to pitch and yaw (IJKL by default) 
Translate FWD (H by default) to auto-level planes
Translate BACK (N by default) to auto-upright rockets
Translate UP (LeftShift by default) 
Translate DOWN (LeftControl by default)